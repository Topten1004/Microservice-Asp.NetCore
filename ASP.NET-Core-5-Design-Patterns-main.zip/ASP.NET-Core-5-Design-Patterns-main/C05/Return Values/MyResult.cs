﻿namespace Return_Values
{
    public class MyResult
    {
        public int Input { get; set; }
        public string Value { get; set; }
    }
}
