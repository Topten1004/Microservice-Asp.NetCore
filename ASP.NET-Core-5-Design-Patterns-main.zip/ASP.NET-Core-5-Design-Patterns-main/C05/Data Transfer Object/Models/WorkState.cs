﻿namespace WebApi.Models
{
    public enum WorkState
    {
        New,
        InProgress,
        Completed
    }
}
