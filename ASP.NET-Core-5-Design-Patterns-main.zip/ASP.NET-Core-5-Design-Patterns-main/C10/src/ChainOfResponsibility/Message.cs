﻿namespace ChainOfResponsibility
{
    public class Message
    {
        public string Name { get; set; }
        public string Payload { get; set; }
    }
}
