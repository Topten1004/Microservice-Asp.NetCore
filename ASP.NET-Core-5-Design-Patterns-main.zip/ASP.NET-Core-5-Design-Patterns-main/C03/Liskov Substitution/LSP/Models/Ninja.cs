﻿namespace LSP.Models
{
    public class Ninja
    {
        public int Kills { get; set; }
    }
}
