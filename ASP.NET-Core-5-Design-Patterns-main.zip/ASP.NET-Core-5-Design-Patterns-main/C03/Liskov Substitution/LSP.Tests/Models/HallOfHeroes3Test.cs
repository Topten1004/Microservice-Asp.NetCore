﻿namespace LSP.Examples.Update3
{
    public class HallOfHeroesTest : BaseLSPTest
    {
        protected override HallOfFame sut { get; } = new HallOfHeroes();
    }
}
