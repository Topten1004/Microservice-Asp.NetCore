﻿namespace CommonScenarios
{
    public interface IMyNameService
    {
        string GetName(bool someCondition);
    }
}
