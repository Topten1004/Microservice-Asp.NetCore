﻿namespace CommonScenarios
{
    public class MyNameServiceUsingNamedOptionsMonitorTest : MyNameServiceTest<MyNameServiceUsingNamedOptionsMonitor>
    {
    }
}
