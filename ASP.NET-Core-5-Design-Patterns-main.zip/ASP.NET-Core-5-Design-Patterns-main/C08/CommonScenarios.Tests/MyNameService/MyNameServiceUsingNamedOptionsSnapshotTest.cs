﻿namespace CommonScenarios
{
    public class MyNameServiceUsingNamedOptionsSnapshotTest : MyNameServiceTest<MyNameServiceUsingNamedOptionsSnapshot>
    {
    }
}
