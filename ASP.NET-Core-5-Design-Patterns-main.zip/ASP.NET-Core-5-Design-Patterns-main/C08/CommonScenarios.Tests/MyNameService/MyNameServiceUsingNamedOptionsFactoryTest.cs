﻿namespace CommonScenarios
{
    public class MyNameServiceUsingNamedOptionsFactoryTest : MyNameServiceTest<MyNameServiceUsingNamedOptionsFactory>
    {
    }
}
