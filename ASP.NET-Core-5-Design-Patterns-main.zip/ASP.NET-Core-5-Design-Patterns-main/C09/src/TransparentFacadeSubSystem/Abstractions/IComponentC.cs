﻿namespace TransparentFacadeSubSystem.Abstractions
{
    public interface IComponentC
    {
        string OperationE();
        string OperationF();
    }
}