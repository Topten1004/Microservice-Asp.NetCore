﻿namespace TransparentFacadeSubSystem.Abstractions
{
    public interface IComponentA
    {
        string OperationA();
        string OperationB();
    }
}