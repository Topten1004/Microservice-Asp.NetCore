﻿using TransparentFacadeSubSystem.Abstractions;

namespace Facade
{
    public class UpdatedComponentB : IComponentB
    {
        public string OperationC() => "Flexibility";
        public string OperationD() => "Design Pattern";
    }
}
