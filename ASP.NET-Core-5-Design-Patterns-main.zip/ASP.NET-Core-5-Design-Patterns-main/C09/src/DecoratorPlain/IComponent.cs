﻿namespace DecoratorPlain
{
    public interface IComponent
    {
        string Operation();
    }
}
