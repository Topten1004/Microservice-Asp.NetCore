﻿namespace OpaqueFacadeSubSystem.Abstractions
{
    public interface IOpaqueFacade
    {
        string ExecuteOperationA();
        string ExecuteOperationB();
    }
}
