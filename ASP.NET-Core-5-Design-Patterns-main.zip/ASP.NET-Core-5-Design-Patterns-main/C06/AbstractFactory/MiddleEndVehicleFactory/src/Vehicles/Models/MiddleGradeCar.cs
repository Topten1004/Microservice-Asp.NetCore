﻿namespace Vehicles.Models
{
    public class MiddleGradeCar : ICar { }
}
