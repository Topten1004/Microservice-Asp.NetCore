﻿namespace Vehicles.Models
{
    public class LowGradeBike : IBike { }
}
