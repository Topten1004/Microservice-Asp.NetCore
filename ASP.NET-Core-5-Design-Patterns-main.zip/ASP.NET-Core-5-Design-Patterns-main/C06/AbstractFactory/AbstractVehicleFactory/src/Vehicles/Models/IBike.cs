﻿namespace Vehicles.Models
{
    public interface IBike { }
}
