﻿namespace Vehicles.Models
{
    public class HighGradeCar : ICar { }
}
